import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp
from tkinter import messagebox

root = tk.Tk()
root.title("EMS Gautam Help Page")

root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)

def back():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Help & Support\EMS Help & Support Page.py"],shell=True)
    
def save_to_file(content, file_path):
    try:
        with open(file_path, 'w') as file:
            file.write(content)
        messagebox.showinfo("Success", "Content saved successfully!")
    except Exception as e:
        messagebox.showerror("Error", f"Error saving content: {str(e)}")

def save_content():
    content = issue_box.get("1.0", "end-1c")  # Get content from the text field
    file_path = "C:\Minor Project EMS\EMS Help & Support\Response\Gautam.txt"

    save_to_file(content, file_path)
    
    
def reset_content():
    issue_box.delete("1.0","end-1c")

# Load and display the background image
helpsupport_image = Image.open("C:\Minor Project EMS\IMG\EMS Gautam Help Page.png")
helpsupport_photo = ImageTk.PhotoImage(helpsupport_image)
helpsupport_label = tk.Label(root, image=helpsupport_photo)
helpsupport_label.place(x=0, y=0, width=1540, height=870)

# Text area to write your issues
issue_box = tk.Text(root, font=("Arial",25))
issue_box.place(x=820,y=160,width=632,height=295)

Submit_button = tk.Button(root, text="Submit Response", bg="blue",fg="white",font=("Cooper Black",16),command=lambda : [save_content(), root.quit()])
Submit_button.place(x=1250, y=480, width=210, height=70)

Reset_button = tk.Button(root, text="Reset Response", bg="blue",fg="white",font=("Cooper Black",16),command=reset_content)
Reset_button.place(x=1000, y=480, width=210, height=70)


# Exit button to close the application & Home button to reach again on Main page.

home_logo = Image.open("C:\Minor Project EMS\IMG\home_button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=450, y=100, width=120, height=120)

exit_logo = Image.open("C:\Minor Project EMS\IMG\exit_button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=650, y=100, width=120, height=120)

# Back button to close the application
back_logo = Image.open("C:\Minor Project EMS\IMG\EMS Back Help Logo.png")
back_logo = ImageTk.PhotoImage(back_logo)
back_button = tk.Button(root, image=back_logo, command=lambda :[back(), root.quit()])
back_button.place(x=718, y=620, width=140, height=126)


# Start the main loop
root.mainloop()
