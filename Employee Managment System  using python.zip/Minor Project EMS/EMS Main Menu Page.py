import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp

# Create the main window
root = tk.Tk()
root.title("Employee Management System")
root.attributes('-fullscreen', True)

def emp_pannel():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMS Pannel Page.py"],shell=True)
    
def performance():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Performance\EMS Performance Page.py"],shell=True)
    
def salary():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Salary\EMS Salary Page.py"],shell=True)
    
def helpsupport():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Help & Support\EMS Help & Support Page.py"],shell=True)
    
    

# Load and display the background image
background_image = Image.open("C:\Minor Project EMS\IMG\EMS Main Menu BG.png")
background_photo = ImageTk.PhotoImage(background_image)
background_label = tk.Label(root, image=background_photo)
background_label.place(x=0, y=0, width=1550, height=870)



# Create circular buttons with logos
emp_pannel_button = Image.open("C:\Minor Project EMS\IMG\EMS Emp Pannel Logo.png")
emp_pannel_button = ImageTk.PhotoImage(emp_pannel_button)
button1 = tk.Button(root, image=emp_pannel_button, command=lambda : [root.quit(), emp_pannel()])
button1.place(x=127, y=100, width=405, height=245)

emp_perf_button = Image.open("C:\Minor Project EMS\IMG\EMS Performance Logo.png")
emp_perf_button = ImageTk.PhotoImage(emp_perf_button)
button2 = tk.Button(root, image=emp_perf_button, command=lambda : [root.quit(), performance()])
button2.place(x=1027, y=100, width=405, height=245)

emp_salary_button = Image.open("C:\Minor Project EMS\IMG\EMS Salary Logo.png")
emp_salary_button = ImageTk.PhotoImage(emp_salary_button)
button3 = tk.Button(root, image=emp_salary_button, command=lambda : [root.quit(), salary()])
button3.place(x=125, y=555, width=405, height=245)

emp_help_button = Image.open("C:\Minor Project EMS\IMG\EMS Help Support Logo.png")
emp_help_button = ImageTk.PhotoImage(emp_help_button)
button4 = tk.Button(root, image=emp_help_button, command=lambda : [root.quit(), helpsupport()])
button4.place(x=1008, y=555, width=405, height=245)

# Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\IMG\EMS Exit Logo.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=700, y=702, width=145, height=145)

# Start the main loop
root.mainloop()
