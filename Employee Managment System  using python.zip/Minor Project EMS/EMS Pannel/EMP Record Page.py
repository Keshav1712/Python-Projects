import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess as subp
import pymysql

root = tk.Tk()
root.title("Employee Records Page")
root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)
    
def back():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMS Pannel Page.py"],shell=True)  
    
    
def fetch_data():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="12345",
        database="employee",
        cursorclass=pymysql.cursors.DictCursor
    )

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM employee_data")
            data = cursor.fetchall()
            for row in data:
                tree.insert("", "end", values=list(row.values()))
    finally:
        connection.close()    
        
def search_data():
    search_field = Search_box_box.get()
    search_text = Search_txt.get()

    # Add logic to perform the search based on the search_field and search_text
    # Update the Treeview with the search results

def delete_data():
    selected_item = tree.selection()
    if selected_item:
        # Extract the employee ID from the selected item
        emp_id = tree.item(selected_item, 'values')[0]

        # Open a database connection
        connection = pymysql.connect(
            host="localhost",
            user="root",
            password="12345",
            database="employee",
            cursorclass=pymysql.cursors.DictCursor
        )

        try:
            with connection.cursor() as cursor:
                # Delete the record with the specified employee ID
                sql = "DELETE FROM employee_data WHERE id = %s"
                cursor.execute(sql, (emp_id,))
                connection.commit()

                # Remove the selected item from the Treeview
                tree.delete(selected_item)
        except Exception as e:
            # Handle any exceptions that may occur during the deletion
            print(f"Error deleting recorC: {e}")
        finally:
            # Close the database connection
            connection.close()

def edit_data():
    selected_item = tree.selection()
    if selected_item:
        # Extract the employee ID or other unique identifier from the selected item
        emp_id = tree.item(selected_item, 'values')[0]
    
        
emp_reg_photo = Image.open("C:\Minor Project EMS\IMG\EMS Pannel Background.png")
emp_reg_photo = ImageTk.PhotoImage(emp_reg_photo)
emp_reg_label = tk.Label(root, image=emp_reg_photo)
emp_reg_label.place(x=0, y=0, width=1540, height=870)


title_lb1 = tk.Label(root,text="Employees Record",font=("verdana",50,"bold"),fg="navyblue",bg="#33A5FF")
title_lb1.place(x=370,y=44,width=800,height=70)

home_logo = Image.open("C:\Minor Project EMS\EMS Pannel\home_button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=20, y=377, width=120, height=120)

# Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\EMS Pannel\exit_button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=1400, y=377, width=120, height=120)

# Back button to close the application
back_logo = Image.open("C:\Minor Project EMS\IMG\EMS Back Emp Pannel Logo.png")
back_logo = ImageTk.PhotoImage(back_logo)
back_button = tk.Button(root, image=back_logo, command=lambda :[back(), root.quit()])
back_button.place(x=715, y=750, width=100, height=100)

# Create a Treeview widget
columns = ("Emp ID","First Name", "Last Name", "Gender", "Date of Birth", "Father's Name", "Mother's Name", 
           "PIN Code", "Address", "City", "State", "Email", "Phone No", "Marital Status", 
           "Job Type", "Department", "Designation", "Salary")


tree = ttk.Treeview(root, columns=columns, show="headings")

# Add column headings
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=100, anchor='center')
    
# Fetch data from the database and populate the table
fetch_data()

# Place the Treeview widget on the window
tree.place(x=170, y=220, width=1200, height=430)

#Search Of Employee.
Search_box = tk.Label(root,text="Search :",font=("times new roman",30,"bold"),fg="#002B53",anchor="w")
Search_box.place(x=170,y=160,width=150,height=50)
 
Search_box_box= ttk.Combobox(root,font=("times new roman",25,"bold"),state="readonly")
Search_box_box["values"]=("--Search Field--","Emp ID","First Name", "Last Name", "Gender", "Date of Birth", "Father's Name", "Mother's Name", 
           "PIN Code", "Address", "City", "State", "Email", "Phone No", "Marital Status", "Job Type", "Department", "Designation", "Salary")
Search_box_box.current(0)
Search_box_box.place(x=330,y=160,width=270,height=50)

Search_txt= tk.Entry(root,font=("times new roman",25,"bold"))
Search_txt.place(x=950,y=160,width=270,height=50)

Search_Btn= tk.Button(root,text="Search",font=("times new roman",25,"bold"),command=search_data)
Search_Btn.place(x=1220,y=160,width=150,height=50)

Edit_Btn= tk.Button(root,text="Edit Details",font=("times new roman",30,"bold"),command=edit_data)
Edit_Btn.place(x=250,y=655,width=300,height=70)

Delete_Btn= tk.Button(root,text="Delete Details",font=("times new roman",30,"bold"),command=delete_data)
Delete_Btn.place(x=1000,y=655,width=300,height=70)


root.mainloop()