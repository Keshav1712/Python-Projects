import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp
import webbrowser

root = tk.Tk()
root.title("Employee Salary")
root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)


# Load and display the background image
salary_image = Image.open("C:\Minor Project EMS\IMG\EMS Salary Page Background.png")
salary_image = ImageTk.PhotoImage(salary_image)
salary_label = tk.Label(root, image=salary_image)
salary_label.place(x=0, y=0, width=1540, height=870)

# Create circular buttons with logos
emp_salary_slip = Image.open("C:\Minor Project EMS\IMG\EMS Salary Slip Button.png")
emp_salary_slip = ImageTk.PhotoImage(emp_salary_slip)
kk_button = tk.Button(root, image=emp_salary_slip, command=root.quit)
kk_button.place(x=335, y=350, width=290, height=320)



emp_salary_record = Image.open("C:\Minor Project EMS\IMG\EMS Salary Record Button.png")
emp_salary_record = ImageTk.PhotoImage(emp_salary_record)
gk_button = tk.Button(root, image=emp_salary_record, command=root.quit)
gk_button.place(x=895, y=350, width=290, height=320)

home_logo = Image.open("C:\Minor Project EMS\IMG\EMS Salary Home Button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=105, y=380, width=150, height=150)

# Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\IMG\EMS Salary Exit Button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=1280, y=380, width=150, height=150)

# Start the main loop
root.mainloop()
