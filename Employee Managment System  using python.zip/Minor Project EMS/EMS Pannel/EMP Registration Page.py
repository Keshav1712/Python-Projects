import tkinter as tk
from tkinter import *
from PIL import Image, ImageTk
import subprocess as subp
import sqlite3
from tkinter import ttk
from tkinter import filedialog
from tkinter.filedialog import askopenfile
import tkinter as tk
from tkcalendar import DateEntry
import mysql.connector
import pymysql
from datetime import datetime
from tkinter import messagebox




root = tk.Tk()
root.title("Employee Registration Form")
root.attributes('-fullscreen', True)


Emp_FirstName=StringVar()
Emp_LastName=StringVar()
Emp_Gender=StringVar()
Emp_DoB=StringVar()
Emp_FName=StringVar()
Emp_MName=StringVar()
Emp_PinCode=StringVar()
Emp_Address=StringVar()
Emp_City=StringVar()
Emp_State=StringVar()
Emp_Email=StringVar()
Emp_PNo=StringVar()
Emp_MStatus=StringVar()
Emp_JTpye=StringVar()
Emp_Department=StringVar()
Emp_Position=StringVar()
Emp_Salary=StringVar()

def upload_file():
    global img
    f_types = [('Jpg Files', '*.jpg')]
    filename = filedialog.askopenfilename(filetypes=f_types)
    img = ImageTk.PhotoImage(file=filename)
    img_l = tk.Label(root,image=img)
    img_l.place(x=185,y=200,width=300,height=350)
    
def img_reset():
    reset_img = tk.Label(root,image=None)
    reset_img.place(x=185,y=200,width=300,height=350)
    

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)
    
def back():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMS Pannel Page.py"],shell=True)
    
    
def create_connection():
    try:
        connection = pymysql.connect(
            host="localhost",
            user="root",
            password="keshav2005",
            database="employee",
            cursorclass=pymysql.cursors.DictCursor
        )
        return connection
    except pymysql.Error as err:
        print(f"Error: {err}")
        return None    

    
def save_data():
    
    f_name=Emp_FirstName.get()
    l_name=Emp_LastName.get()
    gender=Emp_Gender.get()
    dob=Emp_DoB.get()
    father_name=Emp_FName.get()
    mother_name=Emp_MName.get()
    pin=Emp_PinCode.get()
    add=Emp_Address.get()
    city=Emp_City.get()
    estate=Emp_State.get()  
    email_id=Emp_Email.get()
    phone_no=Emp_PNo.get()
    m_status=Emp_MStatus.get()
    job_type=Emp_JTpye.get()
    depart=Emp_Department.get()
    designation=Emp_Position.get()
    month_salary=Emp_Salary.get()

    try:
        connection = create_connection()
        if connection:
            cursor = connection.cursor()

            # Your SQL query to insert data
            sql_query = "INSERT INTO employee_data (first_name, last_name, gender, dob, father_name, mother_name, pin, address, city, state, email, phone_no, marital_status, job_type, department, designation, salary) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            
            # Tuple containing the values to be inserted
            data = (f_name, l_name, gender, dob, father_name, mother_name, pin, add, city, estate, email_id, phone_no, m_status, job_type, depart, designation, month_salary)

            cursor.execute(sql_query, data) 

            # Commit changes
            connection.commit()

            print("Data inserted successfully!")

        else:
           print("Failed to connect to the database.")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        if connection:
            connection.close()
            
            
    dob = Emp_DoB_Select.get()
    if not dob:
        print("Date of Birth is required.")
        return

    try:
        # Parse the date of birth to ensure it's a valid date format
        dob_datetime = datetime.strptime(dob, '%m/%d/%y')
        dob_formatted = dob_datetime.strftime('%Y-%m-%d')

        connection = create_connection()
        if connection:
            cursor = connection.cursor()

            # Your SQL query to insert data
            sql_query = "INSERT INTO employee_data (first_name, last_name, gender, dob, father_name, mother_name, pin, address, city, state, email, phone_no, marital_status, job_type, department, designation, salary) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            
            # Tuple containing the values to be inserted
            data = (f_name, l_name, gender, dob_formatted, father_name, mother_name, pin, add, city, estate, email_id, phone_no, m_status, job_type, depart, designation, month_salary)

            cursor.execute(sql_query, data)

            # Commit changes
            connection.commit()

            print("Data inserted successfully!")

        else:
            print("Failed to connect to the database.")

    except Exception as e:
        print(f"Error: {e}")

    finally:
        if connection:
            connection.close()
                
    
def reset_data():
    Emp_FirstName.set(""),
    Emp_LastName.set(""),
    Emp_Gender.set(""),
    Emp_DoB.set(""),
    Emp_FName.set(""),
    Emp_MName.set(""),
    Emp_PinCode.set(""),
    Emp_Address.set(""),
    Emp_City.set(""),
    Emp_State.set("---Select State---"),
    Emp_Email.set(""),
    Emp_PNo.set(""),
    Emp_MStatus.set("--Marital Status--"),
    Emp_JTpye.set(""),
    Emp_Department.set("--Department--"),
    Emp_Position.set("---Designation--"),
    Emp_Salary.set("")


#---------------------------------------------Page formation-------------------------------------------------------------------------------
        
emp_reg_photo = Image.open("C:\Minor Project EMS\IMG\EMS Pannel Background.png")
emp_reg_photo = ImageTk.PhotoImage(emp_reg_photo)
emp_reg_label = tk.Label(root, image=emp_reg_photo)
emp_reg_label.place(x=0, y=0, width=1540, height=870)


title_lb1 = tk.Label(root,text="Employee Registration Form",font=("verdana",50,"bold"),fg="navyblue",bg="#33A5FF")
title_lb1.place(x=220,y=44,width=1100,height=70)

home_logo = Image.open("C:\Minor Project EMS\EMS Pannel\home_button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=20, y=377, width=120, height=120)

# Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\EMS Pannel\exit_button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=1400, y=377, width=120, height=120)

# Back button to close the application
back_logo = Image.open("C:\Minor Project EMS\IMG\EMS Back Emp Pannel Logo.png")
back_logo = ImageTk.PhotoImage(back_logo)
back_button = tk.Button(root, image=back_logo, command=lambda :[back(), root.quit()])
back_button.place(x=715, y=750, width=100, height=100)


#Photo upload

blankphoto = Image.open("C:\Minor Project EMS\IMG\Blank Photo.png")
blankphoto = ImageTk.PhotoImage(blankphoto)
blankphoto_label = tk.Label(root, image=blankphoto)
blankphoto_label.place(x=185,y=200,width=300,height=350)

Img_ins = tk.Label(root,text="**Image size = 300mm X 350mm",font=("times new roman",16,"bold"),fg="#002B53",anchor="w")
Img_ins.place(x=185,y=555,width=300,height=30)

upload_btn= tk.Button(root, text='Upload File',font=("times new roman",20,"bold"),command = lambda:upload_file())
upload_btn.place(x=185,y=595,width=300,height=50)
reset_btn= tk.Button(root, text='Reset Image',font=("times new roman",20,"bold"),command = lambda:img_reset())
reset_btn.place(x=185,y=650,width=300,height=50)

#Element of Registration Form
#label1
FName = tk.Label(root,text="First Name:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
FName.place(x=495,y=200,width=195,height=30)

#entry1 
FName_txt= tk.Entry(root,textvariable=Emp_FirstName,font=("times new roman",20,"bold"))
FName_txt.place(x=700,y=200,width=210,height=30)


#label2 
Lname =tk.Label(root,text="Last Name:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Lname.place(x=940,y=200,width=195,height=30)

#entry2 
Lname_txt=tk.Entry(root,textvariable=Emp_LastName,font=("times new roman",20,"bold"))
Lname_txt.place(x=1150,y=200,width=210,height=30)

#label3
Gender = tk.Label(root,text="Gender:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Gender.place(x=495,y=250,width=195,height=30)

#entry3 
Gender_radiobtn1= ttk.Radiobutton(root,text="Male",variable=Emp_Gender,value="male")
Gender_radiobtn1.place(x=700,y=250,width=195,height=30)

Gender_radiobtn1= ttk.Radiobutton(root,text="Female",variable=Emp_Gender,value="female")
Gender_radiobtn1.place(x=810,y=250,width=100,height=30)


#label4 
DoB =tk.Label(root,text="Date of Birth :",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
DoB.place(x=940,y=250,width=195,height=30)

#entry4
Emp_DoB_Select = DateEntry(root, datepattern='dd-mm-yyyy',font=("times new roman",16,"bold"),fg="#002B53",anchor="w",)
Emp_DoB_Select.place(x=1150,y=250,width=210,height=30)

#label5
Fathname = tk.Label(root,text="Father's Name:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Fathname.place(x=495,y=300,width=195,height=30)

#entry5
Fathname_txt= tk.Entry(root,textvariable=Emp_FName,font=("times new roman",20,"bold"))
Fathname_txt.place(x=700,y=300,width=210,height=30)


#label6
Mothname =tk.Label(root,text="Mother's Name:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Mothname.place(x=940,y=300,width=195,height=30)

#entry6
Mothname_txt=tk.Entry(root,textvariable=Emp_MName,font=("times new roman",20,"bold"))
Mothname_txt.place(x=1150,y=300,width=210,height=30)

#label7
Address = tk.Label(root,text="Address:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Address.place(x=495,y=350,width=195,height=30)

#entry7
Address_txt= tk.Entry(root,textvariable=Emp_Address,font=("times new roman",20,"bold"))
Address_txt.place(x=700,y=350,width=660,height=30)

#label8
City_lab =tk.Label(root,text="City:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
City_lab.place(x=495,y=400,width=80,height=30)

#entry8
City_txt=tk.Entry(root,textvariable=Emp_City,font=("times new roman",20,"bold"))
City_txt.place(x=585,y=400,width=195,height=30)


#label9
State =tk.Label(root,text="State:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
State.place(x=800,y=400,width=100,height=30)

#entry9
Emp_State_Combo_Box= ttk.Combobox(root,textvariable=Emp_State,font=("times new roman",18,"bold"),state="readonly")
Emp_State_Combo_Box["values"]=("---Select State---","Andhra Pradesh","Arunachal Pradesh ","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman & Nicobar Islands","Chandigarh","Dadra & Nagar Haveli","Daman and Diu","Lakshadweep","NCT of Delhi","Puducherry")
Emp_State_Combo_Box.current(0)
Emp_State_Combo_Box.place(x=910,y=400,width=195,height=30)


#label10
PINCod =tk.Label(root,text="PIN Code:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
PINCod.place(x=1120,y=400,width=130,height=30)

#entry10
PIN_txt=tk.Entry(root,textvariable=Emp_PinCode,font=("times new roman",20,"bold"))
PIN_txt.place(x=1260,y=400,width=100,height=30)

#label11
Email = tk.Label(root,text="E-Mail IC:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Email.place(x=495,y=450,width=195,height=30)

#entry11 
Emp_Email_txt= tk.Entry(root,textvariable=Emp_Email,font=("times new roman",20,"bold"))
Emp_Email_txt.place(x=700,y=450,width=210,height=30)


#label12 
Phoneno =tk.Label(root,text="Contact No.:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Phoneno.place(x=940,y=450,width=195,height=30)

#entry12 
Phoneno_txt=tk.Entry(root,textvariable=Emp_PNo,font=("times new roman",20,"bold"))
Phoneno_txt.place(x=1150,y=450,width=210,height=30)

#label13
Marital = tk.Label(root,text="Marital Status :",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Marital.place(x=495,y=500,width=195,height=30)

#entry13 
Marital_box= ttk.Combobox(root,textvariable=Emp_MStatus,font=("times new roman",18,"bold"),state="readonly")
Marital_box["values"]=("--Marital Status--","Married","Single","Divorced","Widowed","Separated")
Marital_box.current(0)
Marital_box.place(x=700,y=500,width=210,height=30)


#label14
Depart =tk.Label(root,text="Department:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Depart.place(x=940,y=500,width=195,height=30)

#entry14 
Depart_box=ttk.Combobox(root,textvariable=Emp_Department,font=("times new roman",18,"bold"),state="readonly")
Depart_box["values"]=("--Department--","Technial","Non-Technical","Financial","Marketing","IT & Computer","Recruitment","Research & Development")
Depart_box.current(0)
Depart_box.place(x=1150,y=500,width=210,height=30)

#label15
Jobtype = tk.Label(root,text="Job Type:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Jobtype.place(x=495,y=550,width=195,height=30)

#entry15
Jobtype_radiobtn1= ttk.Radiobutton(root,text="Regular(Permanent)",variable=Emp_JTpye,value="regular")
Jobtype_radiobtn1.place(x=700,y=550,width=150,height=30)

Jobtype_radiobtn2= ttk.Radiobutton(root,text="Contractual(Temporary)",variable=Emp_JTpye,value="contractual")
Jobtype_radiobtn2.place(x=900,y=550,width=150,height=30)

Jobtype_radiobtn3= ttk.Radiobutton(root,text="Intern",variable=Emp_JTpye,value="intern")
Jobtype_radiobtn3.place(x=1100,y=550,width=150,height=30)


#label16
Post = tk.Label(root,text="Designation:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
Post.place(x=495,y=600,width=195,height=30)

#entry16
Post_Box=ttk.Combobox(root,textvariable=Emp_Position,font=("times new roman",18,"bold"),state="readonly")
Post_Box["values"]=["---Designation---","Technician", "Clerk","Assistant","Section Officer", "HR Manager", "Software Engineer", "Marketing Specialist", "Sales Representative", "Data Scientist", "Project Manager", "Customer Support"]
Post_Box.current(0)
Post_Box.place(x=700,y=600,width=210,height=30)


#label17
MEmp_Salary =tk.Label(root,text="Monthly Salary:",font=("times new roman",20,"bold"),fg="#002B53",anchor="w")
MEmp_Salary.place(x=940,y=600,width=195,height=30)

#entry17
MEmp_Salary_txt=tk.Entry(root,textvariable=Emp_Salary,font=("times new roman",20,"bold"))
MEmp_Salary_txt.place(x=1150,y=600,width=210,height=30)

reset_form_btn= tk.Button(root, text='RESET',font=("times new roman",20,"bold"),command = reset_data)
reset_form_btn.place(x=930,y=650,width=210,height=50)

submit_btn= tk.Button(root, text='SUBMIT',font=("times new roman",20,"bold"),command = lambda : [save_data(), root.quit(), back()])
submit_btn.place(x=1150,y=650,width=210,height=50)

root.mainloop()