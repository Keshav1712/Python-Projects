import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess as subp
import webbrowser
import pymysql

root = tk.Tk()
root.title("Employee Records Page")
root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"], shell=True)
    
def back():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMS Pannel Page.py"], shell=True)

# Function to fetch data from the database
def fetch_data():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="12345",
        database="employee",
        cursorclass=pymysql.cursors.DictCursor
    )

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM employee_data")
            data = cursor.fetchall()
            for row in data:
                tree.insert("", "end", values=list(row.values()))
    finally:
        connection.close()

# Create a Treeview widget
columns = ("Emp_ID","First Name", "Last Name", "Gender", "Date of Birth", "Father's Name", "Mother's Name", 
           "PIN Code", "Address", "City", "State", "Email", "Phone No", "Marital Status", 
           "Job Type", "Department", "Designation", "Salary")

tree = ttk.Treeview(root, columns=columns, show="headings")

# Add column headings
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=100, anchor='center')

# Fetch data from the database and populate the table
fetch_data()

# Place the Treeview widget on the window
tree.place(x=20, y=150, width=1500, height=600)

# Rest of your code for the GUI layout (background, buttons, etc.)

root.mainloop()
