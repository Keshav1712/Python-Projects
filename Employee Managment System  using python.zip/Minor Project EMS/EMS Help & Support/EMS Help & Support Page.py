import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp
import webbrowser

root = tk.Tk()
root.title("EMS Help & Support PAge")

root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)

def keshav():
     subp.Popen(["python", "C:\Minor Project EMS\EMS Help & Support\EMS Keshav Page.py"],shell=True)
    
def gautam():
     subp.Popen(["python", "C:\Minor Project EMS\EMS Help & Support\EMS Gautam Page.py"],shell=True)
    
def vivek():
     subp.Popen(["python", "C:\Minor Project EMS\EMS Help & Support\EMS Vivek Page.py"],shell=True)
     
     

# Load and display the background image
helpsupport_image = Image.open("C:\Minor Project EMS\IMG\EMS Help Page Background.png")
helpsupport_photo = ImageTk.PhotoImage(helpsupport_image)
helpsupport_label = tk.Label(root, image=helpsupport_photo)
helpsupport_label.place(x=0, y=0, width=1540, height=870)

#About Developer Gautam Kumar

gk_logo = Image.open("C:\Minor Project EMS\IMG\gk_logo.png")
gk_logo = ImageTk.PhotoImage(gk_logo)
gk_button = tk.Button(root, image=gk_logo, command=lambda : [gautam(), root.quit()])
gk_button.place(x=150, y=325, width=214, height=208)

#About Developer Keshav Kumar

kk_logo = Image.open("C:\Minor Project EMS\IMG\kk_logo.png")
kk_logo = ImageTk.PhotoImage(kk_logo)
kk_button = tk.Button(root, image=kk_logo, command=lambda : [keshav(), root.quit()])
kk_button.place(x=662, y=325, width=214, height=208)

#About Developer Vivek Kumar

vk_logo = Image.open(r"C:\Minor Project EMS\IMG\vk_logo.png")
vk_logo = ImageTk.PhotoImage(vk_logo)
vk_button = tk.Button(root, image=vk_logo, command=lambda : [vivek(), root.quit()])
vk_button.place(x=1173, y=325, width=214, height=208)

# Exit button to close the application & Home button to reach again on Main page.

home_logo = Image.open("C:\Minor Project EMS\IMG\home_button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=30, y=30, width=120, height=120)

exit_logo = Image.open("C:\Minor Project EMS\IMG\exit_button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=1400, y=30, width=120, height=120)


# Start the main loop
root.mainloop()
