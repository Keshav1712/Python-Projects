import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp
import webbrowser


root = tk.Tk()
root.title("Employees Pannel")
root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)

def reg():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMP Registration Page.py"],shell=True)
    
def prof():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMP Profile Page.py"],shell=True)
    
def record():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMP Record Page.py"],shell=True)


# Load and display the background image

emp_pannel_photo = Image.open("C:\Minor Project EMS\IMG\EMS Pannel Page Background.png")
emp_pannel_photo = ImageTk.PhotoImage(emp_pannel_photo)
emp_pannel_label = tk.Label(root, image=emp_pannel_photo)
emp_pannel_label.place(x=0, y=0, width=1540, height=870)


# Create circular buttons with logos
emp_reg = Image.open("C:\Minor Project EMS\IMG\EMP Registration Logo.png")
emp_reg = ImageTk.PhotoImage(emp_reg)
emp_reg_button = tk.Button(root, image=emp_reg, command=lambda : [reg(), root.quit()])
emp_reg_button.place(x=155, y=290, width=340, height=280)


emp_prof = Image.open("C:\Minor Project EMS\IMG\EMP Profile Logo.png")
emp_prof = ImageTk.PhotoImage(emp_prof)
emp_prof_button = tk.Button(root, image=emp_prof, command=lambda : [prof(), root.quit()])
emp_prof_button.place(x=590, y=402, width=340, height=280)

emp_record = Image.open("C:\Minor Project EMS\IMG\EMP Record Logo.png")
emp_record = ImageTk.PhotoImage(emp_record)
emp_record_button = tk.Button(root, image=emp_record, command=lambda : [record(), root.quit()])
emp_record_button.place(x=1025, y=292, width=340, height=280)

home_logo = Image.open("C:\Minor Project EMS\IMG\EMS Pannel Home Button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=74, y=56, width=121, height=138)

#Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\IMG\EMS Pannel Exit Button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=1330, y=56, width=122, height=139)

# Start the main loop
root.mainloop()
