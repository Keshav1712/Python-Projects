import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp
import webbrowser

root = tk.Tk()
root.title("Performance")
root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)

def link():
    url="vk652592@gmail.com"
    webbrowser.open(url)

# Load and display the background image
performance_image = Image.open("C:\Minor Project EMS\IMG\EMS Performance Page Background.png")
performance_photo = ImageTk.PhotoImage(performance_image)
performance_label = tk.Label(root, image=performance_photo)
performance_label.place(x=0, y=0, width=1540, height=870)


# Create circular buttons with logos
emp_attend_logo = Image.open("C:\Minor Project EMS\IMG\EMP Attendance Logo.png")
emp_attend_logo = ImageTk.PhotoImage(emp_attend_logo)
emp_attend_button = tk.Button(root, image=emp_attend_logo, command=link)
emp_attend_button.place(x=150, y=330, width=420, height=170)


emp_perf_logo = Image.open("C:\Minor Project EMS\IMG\EMP Performance Logo.png")
emp_perf_logo = ImageTk.PhotoImage(emp_perf_logo)
emp_perf_button = tk.Button(root, image=emp_perf_logo, command=link)
emp_perf_button.place(x=965, y=330,  width=420, height=170)

home_logo = Image.open("C:\Minor Project EMS\IMG\EMS Performance Home Button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=1205, y=695, width=140, height=140)

# Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\IMG\EMS Performance Exit Button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=195, y=695, width=140, height=140)

# Start the main loop
root.mainloop()
