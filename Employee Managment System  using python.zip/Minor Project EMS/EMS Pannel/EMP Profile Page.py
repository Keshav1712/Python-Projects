import tkinter as tk
from PIL import Image, ImageTk
import subprocess as subp
import webbrowser

root = tk.Tk()
root.title("Employee Profile Page")
root.attributes('-fullscreen', True)

def main():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Main Menu Page.py"],shell=True)
    
def back():
    subp.Popen(["python", "C:\Minor Project EMS\EMS Pannel\EMS Pannel Page.py"],shell=True)
        
emp_reg_photo = Image.open("C:\Minor Project EMS\IMG\EMS Pannel Background.png")
emp_reg_photo = ImageTk.PhotoImage(emp_reg_photo)
emp_reg_label = tk.Label(root, image=emp_reg_photo)
emp_reg_label.place(x=0, y=0, width=1540, height=870)


title_lb1 = tk.Label(root,text="Employees Profile",font=("verdana",50,"bold"),fg="navyblue",bg="#33A5FF")
title_lb1.place(x=370,y=44,width=800,height=70)

home_logo = Image.open("C:\Minor Project EMS\EMS Pannel\home_button.png")
home_logo = ImageTk.PhotoImage(home_logo)
home_button = tk.Button(root, image=home_logo, command=lambda : [main(), root.quit()])
home_button.place(x=20, y=377, width=120, height=120)

# Exit button to close the application
exit_logo = Image.open("C:\Minor Project EMS\EMS Pannel\exit_button.png")
exit_logo = ImageTk.PhotoImage(exit_logo)
exit_button = tk.Button(root, image=exit_logo, command=root.quit)
exit_button.place(x=1400, y=377, width=120, height=120)

# Back button to close the application
back_logo = Image.open("C:\Minor Project EMS\IMG\EMS Back Emp Pannel Logo.png")
back_logo = ImageTk.PhotoImage(back_logo)
back_button = tk.Button(root, image=back_logo, command=lambda :[back(), root.quit()])
back_button.place(x=715, y=750, width=100, height=100)



root.mainloop()